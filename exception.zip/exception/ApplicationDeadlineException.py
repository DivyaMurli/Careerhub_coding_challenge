from datetime import datetime

class ApplicationDeadlineException(Exception):
    pass

def check_application_deadline(application_date: str, deadline_date: str):
    try:
        application_datetime = datetime.strptime(application_date, "%Y-%m-%d %H:%M:%S")
        deadline_datetime = datetime.strptime(deadline_date, "%Y-%m-%d %H:%M:%S")
        
        if application_datetime > deadline_datetime:
            raise ApplicationDeadlineException("The application deadline has passed. You cannot apply anymore.")
        else:
            print("Application submitted successfully!")
    except ApplicationDeadlineException as e:
        print(e)

# Example application submission
check_application_deadline("2025-04-16 12:00:00", "2025-04-15 23:59:59")
