
import os
class FileUploadException(Exception):
    pass

class FileSizeExceededException(FileUploadException):
    pass

class UnsupportedFileFormatException(FileUploadException):
    pass

def upload_resume(file_path: str):
    max_size = 5 * 1024 * 1024  # 5MB max file size
    supported_formats = ['pdf', 'docx', 'txt']
    
    try:
        # Check if file exists
        if not os.path.exists(file_path):
            raise FileUploadException("File not found.")
        
        # Check file size
        file_size = os.path.getsize(file_path)
        if file_size > max_size:
            raise FileSizeExceededException("File size exceeds the limit of 5MB.")
        
        # Check file format
        file_extension = file_path.split('.')[-1]
        if file_extension not in supported_formats:
            raise UnsupportedFileFormatException(f"Unsupported file format. Only {', '.join(supported_formats)} are allowed.")
        
        print("File uploaded successfully!")
    except FileUploadException as e:
        print(e)

upload_resume("resume.pdf")
