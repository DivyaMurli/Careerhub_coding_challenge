class InvalidSalaryException(Exception):
    pass

def calculate_average_salary(job_listings):
    try:
        total_salary = 0
        count = 0
        for job in job_listings:
            if job['salary'] < 0:
                raise InvalidSalaryException(f"Invalid salary value for job {job['job_title']}. Salary cannot be negative.")
            total_salary += job['salary']
            count += 1
        if count == 0:
            print("No job listings available.")
            return 0
        return total_salary / count
    except InvalidSalaryException as e:
        print(e)

# Sample job listings data
job_listings = [
    {"job_title": "Software Engineer", "salary": 60000},
    {"job_title": "Data Scientist", "salary": 45000}  # This will trigger the exception
]

average_salary = calculate_average_salary(job_listings)
if average_salary > 0:
    print(f"Average Salary: {average_salary}")

