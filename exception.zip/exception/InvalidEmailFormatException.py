import re

class InvalidEmailFormatException(Exception):
    pass

def validate_email(email: str):
    # Regular expression for a basic email format validation
    email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    if not re.match(email_regex, email):
        raise InvalidEmailFormatException("Invalid email format. Please enter a valid email address.")

def register_applicant():
    email = input("Enter your email: ")
    try:
        validate_email(email)
        print("Email is valid. Proceeding with registration...")
        # Registration logic here
    except InvalidEmailFormatException as e:
        print(e)

register_applicant()

