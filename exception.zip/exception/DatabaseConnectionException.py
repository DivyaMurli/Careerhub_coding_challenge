import pyodbc

class DatabaseConnectionException(Exception):
    pass

def connect_to_database():
    try:
        conn = pyodbc.connect(
            r"Driver={SQL Server};"
            r"Server=DESKTOP-JDMO6DK\SQLEXPRESS;"
            r"Database=careerhub;"
            r"Trusted_Connection=yes;"
        )
        return conn
    except pyodbc.Error as e:
        raise DatabaseConnectionException(f"Database connection failed: {str(e)}")

def retrieve_job_listing():
    try:
        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM JobListings")  # Assuming your table is named JobListings

        rows = cursor.fetchall()
        for row in rows:
            print(row)
        conn.close()
    except DatabaseConnectionException as e:
        print(e)

# ✅ Call the function properly
retrieve_job_listing()
