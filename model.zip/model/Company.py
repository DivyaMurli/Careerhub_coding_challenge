class Company:
    def __init__(self, company_id, company_name, location):
        self.company_id = company_id
        self.company_name = company_name
        self.location = location

    def post_job(self, job_title, job_description, job_location, salary, job_type):
        # Logic for posting a new job listing
        job = JobListing(job_id=None, company_id=self.company_id, job_title=job_title,
                         job_description=job_description, job_location=job_location,
                         salary=salary, job_type=job_type, posted_date=datetime.now())
        db_manager.insert_job_listing(job)

    def get_jobs(self):
        return db_manager.get_job_listings()

