class JobListing:
    def __init__(self, job_id, company_id, job_title, job_description, job_location, salary, job_type, posted_date):
        self.job_id = job_id
        self.company_id = company_id
        self.job_title = job_title
        self.job_description = job_description
        self.job_location = job_location
        self.salary = salary
        self.job_type = job_type
        self.posted_date = posted_date

    def __str__(self):
        return (f"JobID: {self.job_id}, Title: {self.job_title}, "
                f"Company ID: {self.company_id}, Location: {self.job_location}, "
                f"Salary: {self.salary}, Type: {self.job_type}, Posted on: {self.posted_date}")
