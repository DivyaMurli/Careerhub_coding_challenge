# dao/JobBoardService.py


from abc import ABC, abstractmethod
from entity.model.JobListing import JobListing
from entity.model.Company import Company
from entity.model.Applicant import Applicant
from entity.model.JobApplication import JobApplication
from typing import List

class JobBoardService(ABC):
    @abstractmethod
    def insert_job_listing(self, job: JobListing) -> None:
        pass

    @abstractmethod
    def get_jobs_by_salary_range(self, min_salary, max_salary) -> List[JobListing]:
        pass

    @abstractmethod
    def get_job_listings(self) -> List[JobListing]:
        pass

    @abstractmethod
    def insert_applicant(self, applicant: Applicant) -> None:
        pass

    @abstractmethod
    def insert_company(self, company: Company) -> None:
        pass

    @abstractmethod
    def insert_job_application(self, application: JobApplication) -> None:
        pass

    @abstractmethod
    def get_applications_for_job(self, job_id: int) -> List[JobApplication]:
        pass

    @abstractmethod
    def get_companies(self) -> List[Company]:
        pass

    @abstractmethod
    def get_applicants(self) -> List[Applicant]:
        pass
