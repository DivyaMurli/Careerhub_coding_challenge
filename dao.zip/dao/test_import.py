import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'dao')))

try:
    from DatabaseManager import DatabaseManager
    print("Import successful!")
except ImportError as e:
    print(f"Import failed: {e}")
