import sys
import os
import pyodbc  


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

class DatabaseManager:
    def __init__(self):
       
        self.connection_string = r"Driver={SQL Server};Server=DESKTOP-JDMO6DK\SQLEXPRESS;Database=careerhub;Trusted_Connection=yes;"

    def connect(self):
        """Establish a connection to the database."""
        try:
            # Try to establish the connection using pyodbc
            conn = pyodbc.connect(self.connection_string)
            return conn
        except Exception as e:
            raise DatabaseConnectionException(f"Failed to connect to database: {str(e)}")
