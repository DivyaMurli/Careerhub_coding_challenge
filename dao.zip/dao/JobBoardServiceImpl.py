from dao.DatabaseManager import DatabaseManager
from exception.DatabaseConnectionException import DatabaseConnectionException
from dao.JobBoardService import JobBoardService
from entity.model.JobListing import JobListing
from entity.model.Company import Company
from entity.model.Applicant import Applicant
from entity.model.JobApplication import JobApplication
from typing import List

class JobBoardServiceImpl(JobBoardService):
    def __init__(self):
        self.db_manager = DatabaseManager()

    def insert_job_listing(self, job: JobListing) -> None:
        conn = self.db_manager.connect()
        cursor = conn.cursor()
        cursor.execute(""" 
            INSERT INTO JobListings (CompanyID, JobTitle, JobDescription, JobLocation, Salary, JobType, PostedDate)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (job.company_id, job.job_title, job.job_description, job.job_location, job.salary, job.job_type, job.posted_date))
        conn.commit()
        conn.close()

    def get_jobs_by_salary_range(self, min_salary, max_salary) -> List[JobListing]:
        conn = self.db_manager.connect()
        cursor = conn.cursor()
        cursor.execute("""SELECT * FROM JobListings WHERE Salary BETWEEN ? AND ?""", (min_salary, max_salary))
        rows = cursor.fetchall()
        conn.close()
        return [JobListing(*row) for row in rows]

    def get_job_listings(self) -> List[JobListing]:
        conn = self.db_manager.connect()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM JobListings")
        rows = cursor.fetchall()
        conn.close()
        return [JobListing(*row) for row in rows]

    def insert_applicant(self, applicant: Applicant) -> None:
        conn = self.db_manager.connect()
        cursor = conn.cursor()
        cursor.execute(""" 
            INSERT INTO Applicants (FirstName, LastName, Email, Phone, Address)
            VALUES (?, ?, ?, ?, ?)
        """, (applicant.first_name, applicant.last_name, applicant.email, applicant.phone, applicant.address))
        conn.commit()
        conn.close()

    def insert_company(self, company: Company) -> None:
        conn = self.db_manager.connect()
        cursor = conn.cursor()
        cursor.execute(""" 
            INSERT INTO Companies (CompanyName, Address, ContactNumber, Email)
            VALUES (?, ?, ?, ?)
        """, (company.company_name, company.address, company.contact_number, company.email))
        conn.commit()
        conn.close()

    def insert_job_application(self, application: JobApplication) -> None:
        conn = self.db_manager.connect()
        cursor = conn.cursor()
        cursor.execute(""" 
            INSERT INTO JobApplications (JobID, ApplicantID, ApplicationDate, CoverLetter)
            VALUES (?, ?, ?, ?)
        """, (application.job_id, application.applicant_id, application.application_date, application.cover_letter))
        conn.commit()
        conn.close()

    def get_applications_for_job(self, job_id: int) -> List[JobApplication]:
        conn = self.db_manager.connect()
        cursor = conn.cursor()
        cursor.execute("""SELECT * FROM JobApplications WHERE JobID = ?""", (job_id,))
        rows = cursor.fetchall()
        conn.close()
        return [JobApplication(*row) for row in rows]

    def get_companies(self) -> List[Company]:
        conn = self.db_manager.connect()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Companies")
        rows = cursor.fetchall()
        conn.close()
        return [Company(*row) for row in rows]

    def get_applicants(self) -> List[Applicant]:
        conn = self.db_manager.connect()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Applicants")
        rows = cursor.fetchall()
        conn.close()
        return [Applicant(*row) for row in rows]

