import re
import os

class InvalidEmailException(Exception):
    pass

class InvalidFileFormatException(Exception):
    pass

class FileTooLargeException(Exception):
    pass

class Validator:

    @staticmethod
    def validate_email(email: str):
        pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
        if not re.match(pattern, email):
            raise InvalidEmailException(f"Invalid email format: {email}")
        return True

    @staticmethod
    def validate_resume_file(resume_file_path: str):
        # Ensure the file exists
        if not os.path.isfile(resume_file_path):
            raise FileNotFoundError("Resume file not found.")
        
        # Ensure the file is in PDF, DOC, or DOCX format
        valid_extensions = ['.pdf', '.doc', '.docx']
        if not any(resume_file_path.endswith(ext) for ext in valid_extensions):
            raise InvalidFileFormatException("Invalid file format. Only PDF, DOC, and DOCX are allowed.")

        # Check file size (2MB limit)
        file_size = os.path.getsize(resume_file_path)
        if file_size > 2 * 1024 * 1024:  # 2MB limit
            raise FileTooLargeException("File size exceeds 2MB limit.")

        return True
