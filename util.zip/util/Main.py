import sys
import os

# Add root path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from dao.JobBoardServiceImpl import JobBoardServiceImpl
from entity.model.JobListing import JobListing
from entity.model.JobApplication import JobApplication

def main():
    service = JobBoardServiceImpl()

    while True:
        print("\n----- Job Board Menu -----")
        print("1. Post a Job")
        print("2. Apply for a Job")
        print("3. View All Job Listings")
        print("4. Search Jobs by Salary Range")
        print("5. Exit")

        try:
            choice = int(input("Enter your choice: "))
        except ValueError:
            print("Invalid input! Please enter a number.")
            continue

        if choice == 1:
            company_id = int(input("Enter Company ID: "))
            job_title = input("Enter Job Title: ")
            job_description = input("Enter Job Description: ")
            job_location = input("Enter Job Location: ")
            salary = float(input("Enter Salary: "))
            job_type = input("Enter Job Type (Full-time/Part-time): ")
            posted_date = input("Enter Posted Date (YYYY-MM-DD): ")

            job = JobListing(company_id, job_title, job_description, job_location, salary, job_type, posted_date)
            service.insert_job_listing(job)
            print("Job posted successfully!")

        elif choice == 2:
            job_id = int(input("Enter Job ID: "))
            applicant_id = int(input("Enter Applicant ID: "))
            application_date = input("Enter Application Date (YYYY-MM-DD): ")
            cover_letter = input("Enter Cover Letter: ")

            application = JobApplication(job_id, applicant_id, application_date, cover_letter)
            service.insert_job_application(application)
            print("Application submitted successfully!")

        elif choice == 3:
            jobs = service.get_job_listings()
            for job in jobs:
                print(vars(job))

        elif choice == 4:
            min_salary = float(input("Enter minimum salary: "))
            max_salary = float(input("Enter maximum salary: "))
            jobs = service.get_jobs_by_salary_range(min_salary, max_salary)
            for job in jobs:
                print(vars(job))

        elif choice == 5:
            print("Exiting Job Board System.")
            break

        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
